import json
import pathlib
import subprocess
import unittest

BIN = pathlib.Path.home() / 'Applications/TaskFlow Things Access.app/Contents/MacOS/ThingsAccess'

class ProtocolTests(unittest.TestCase):
    def call(self, request):
        result = subprocess.run([str(BIN), '--validate'], input=json.dumps(request), text=True, capture_output=True)
        return json.loads(result.stdout)

    def test_accepts_only_scoped_actions(self):
        for action in ['inspect', 'press', 'set_value', 'key']:
            self.assertTrue(self.call({'action': action, 'snapshot': 'a', 'element': 2, 'value': 'hello', 'key': 'return'})['ok'])

    def test_refuses_arbitrary_application_or_shell(self):
        for request in [{'action': 'shell', 'command': 'whoami'}, {'action': 'inspect', 'bundle_id': 'com.apple.Terminal'}]:
            self.assertFalse(self.call(request)['ok'])

    def test_mutations_require_observed_snapshot(self):
        self.assertFalse(self.call({'action': 'press', 'element': 1})['ok'])
        self.assertFalse(self.call({'action': 'set_value', 'snapshot': 'a', 'element': -1, 'value': 'x'})['ok'])

    def test_no_global_shortcuts(self):
        self.assertFalse(self.call({'action': 'key', 'snapshot': 'a', 'key': 'super+space'})['ok'])

if __name__ == '__main__':
    unittest.main()
