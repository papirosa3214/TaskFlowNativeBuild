import AppKit
import ApplicationServices
import CryptoKit
import Foundation

let bundle = "com.culturedcode.ThingsMac"
let keys: [String: (CGKeyCode, CGEventFlags)] = [
    "return": (36, []), "escape": (53, []), "tab": (48, []), "shift+tab": (48, .maskShift),
    "up": (126, []), "down": (125, []), "left": (123, []), "right": (124, []),
    "space": (49, []), "delete": (51, []), "cmd+a": (0, .maskCommand),
    "cmd+n": (45, .maskCommand), "cmd+shift+n": (45, [.maskCommand, .maskShift]),
    "cmd+r": (15, .maskCommand), "cmd+shift+r": (15, [.maskCommand, .maskShift])
]
func output(_ value: [String: Any]) {
    let data = try! JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
    print(String(data: data, encoding: .utf8)!)
}
func failure(_ message: String, code: String = "UI_ERROR") -> Never {
    output(["ok": false, "error": ["code": code, "message": message]])
    exit(1)
}
let input = FileHandle.standardInput.readDataToEndOfFile()
guard input.count <= 32768,
      let request = try? JSONSerialization.jsonObject(with: input) as? [String: Any],
      let action = request["action"] as? String,
      ["status", "inspect", "press", "select", "set_value", "key"].contains(action),
      request["bundle_id"] == nil else { failure("Invalid scoped Things UI request", code: "BAD_REQUEST") }
if !["status", "inspect"].contains(action) {
    guard let snapshot = request["snapshot"] as? String, !snapshot.isEmpty else { failure("Observe Things first; snapshot is required", code: "BAD_REQUEST") }
    if action == "key" {
        guard let key = request["key"] as? String, keys[key] != nil else { failure("Unsupported or global shortcut", code: "BAD_REQUEST") }
    } else {
        guard let index = request["element"] as? Int, index >= 0 else { failure("Observed element index is required", code: "BAD_REQUEST") }
        if action == "set_value" {
            guard let value = request["value"] as? String, value.count <= 10000 else { failure("Text value up to 10000 characters required", code: "BAD_REQUEST") }
        }
    }
}
if CommandLine.arguments.contains("--validate") { output(["ok": true]); exit(0) }
let trusted = AXIsProcessTrusted()
let session = CGSessionCopyCurrentDictionary() as? [String: Any]
let sessionAvailable = session != nil && (session?["CGSSessionScreenIsLocked"] as? Bool != true)
if action == "status" {
    output(["ok": true, "accessibility": trusted, "bundle_id": bundle,
            "session_available": sessionAvailable])
    exit(0)
}
guard sessionAvailable else { failure("Unlock the macOS session before using Things UI", code: "SESSION_LOCKED") }
guard trusted else { failure("Enable Accessibility for TaskFlow Things Access in macOS Settings; no UI action performed", code: "ACCESSIBILITY_REQUIRED") }
guard let app = NSRunningApplication.runningApplications(withBundleIdentifier: bundle).first else {
    failure("Things is not running in this macOS session", code: "THINGS_OFFLINE")
}
let root = AXUIElementCreateApplication(app.processIdentifier)
AXUIElementSetMessagingTimeout(root, 3)
func attribute(_ element: AXUIElement, _ name: String) -> CFTypeRef? {
    var value: CFTypeRef?
    return AXUIElementCopyAttributeValue(element, name as CFString, &value) == .success ? value : nil
}
func scalar(_ value: CFTypeRef?) -> Any? {
    if let s = value as? String { return String(s.prefix(1200)).replacingOccurrences(of: "(?i)(токен авторизации|authorization token)[ :]+[A-Za-z0-9_-]+", with: "$1 [hidden]", options: .regularExpression) }
    if let n = value as? NSNumber { return n }
    return nil
}
var elements: [AXUIElement] = []
var rows: [[String: Any]] = []
func visit(_ element: AXUIElement, depth: Int, parent: Int?) {
    guard depth < 32, elements.count < 2000 else { return }
    if elements.contains(where: { CFEqual($0, element) }) { return }
    let index = elements.count
    elements.append(element)
    var row: [String: Any] = ["id": index, "depth": depth]
    if let parent { row["parent"] = parent }
    for (key, name) in [("role", kAXRoleAttribute), ("title", kAXTitleAttribute), ("description", kAXDescriptionAttribute), ("value", kAXValueAttribute), ("enabled", kAXEnabledAttribute), ("identifier", kAXIdentifierAttribute)] {
        if let value = scalar(attribute(element, name)) { row[key] = value }
    }
    var actions: CFArray?
    if AXUIElementCopyActionNames(element, &actions) == .success { row["actions"] = actions as? [String] ?? [] }
    rows.append(row)
    if let children = attribute(element, kAXChildrenAttribute) as? [AXUIElement] {
        for child in children { visit(child, depth: depth + 1, parent: index) }
    }
}
visit(root, depth: 0, parent: nil)
// Menu bar is not always part of the application's AXChildren.
if let menu = attribute(root, kAXMenuBarAttribute), CFGetTypeID(menu) == AXUIElementGetTypeID() {
    visit(unsafeBitCast(menu, to: AXUIElement.self), depth: 1, parent: 0)
}
let fingerprint = try! JSONSerialization.data(withJSONObject: rows, options: [.sortedKeys])
let snapshot = SHA256.hash(data: fingerprint).map { String(format: "%02x", $0) }.joined()
if action == "inspect" { output(["ok": true, "snapshot": snapshot, "elements": rows, "truncated": elements.count >= 2000]); exit(0) }
guard request["snapshot"] as? String == snapshot else { failure("Things changed since observation; inspect and use fresh IDs", code: "STALE_SNAPSHOT") }
var result: AXError = .success
if action == "key", let key = request["key"] as? String, let (code, flags) = keys[key] {
    guard let down = CGEvent(keyboardEventSource: nil, virtualKey: code, keyDown: true),
          let up = CGEvent(keyboardEventSource: nil, virtualKey: code, keyDown: false) else { failure("Could not create keyboard event") }
    down.flags = flags; up.flags = flags
    down.postToPid(app.processIdentifier); up.postToPid(app.processIdentifier)
} else {
    guard let index = request["element"] as? Int, elements.indices.contains(index) else { failure("Unknown element index", code: "BAD_REQUEST") }
    let target = elements[index]
    var pid: pid_t = 0
    guard AXUIElementGetPid(target, &pid) == .success, pid == app.processIdentifier else { failure("Target belongs to another application") }
    if action == "press" { result = AXUIElementPerformAction(target, kAXPressAction as CFString) }
    if action == "select" { result = AXUIElementSetAttributeValue(target, kAXSelectedAttribute as CFString, kCFBooleanTrue) }
    if action == "set_value" { result = AXUIElementSetAttributeValue(target, kAXValueAttribute as CFString, request["value"] as! CFString) }
}
guard result == .success else { failure("Things rejected UI action: \(result.rawValue); inspect again") }
output(["ok": true, "performed": action, "verified": false, "next": "inspect and verify the resulting Things state; action acceptance is not completion"])
