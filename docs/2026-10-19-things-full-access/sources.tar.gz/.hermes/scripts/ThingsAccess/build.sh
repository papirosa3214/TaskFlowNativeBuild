#!/bin/bash
set -euo pipefail
src_dir="$HOME/.hermes/scripts/ThingsAccess"
app_dir="$HOME/Applications/TaskFlow Things Access.app"
mkdir -p "$app_dir/Contents/MacOS"
cp "$src_dir/Info.plist" "$app_dir/Contents/Info.plist"
xcrun swiftc -O "$src_dir/main.swift" -o "$app_dir/Contents/MacOS/ThingsAccess" -framework AppKit -framework ApplicationServices -framework CryptoKit
codesign --force --sign - --identifier local.taskflow.things-access "$app_dir"
