"""Documented Things URL commands with bounded, loopback-only receipt handling."""
import http.server
import json
from pathlib import Path
import secrets
import subprocess
import threading
from urllib.parse import urlencode, urlsplit, parse_qs

TOKEN_PATH = Path.home() / '.config/taskflow/things-url-token'


def parameters(tool, arguments):
    update = tool in ('things_update','things_project_update')
    project = tool in ('things_project_add','things_project_update')
    fields = arguments.get('patch', {}) if update else dict(arguments)
    if not isinstance(fields, dict): raise ValueError('patch must be an object')
    allowed = {'title','notes','deadline','due','when','start_date','reminder','reminder_time','tags','project_id','area_id','heading_id','checklist','status','list'}
    if 'recurrence' in fields: raise ValueError('Repeat rules require things_ui; no URL command dispatched')
    unknown = set(fields) - allowed
    if unknown: raise ValueError('Unsupported field(s): '+', '.join(sorted(unknown))+'. Use things_ui for recurrence and UI-only settings; nothing dispatched')
    if fields.get('project_id') and fields.get('area_id'): raise ValueError('Specify one parent: project_id or area_id')
    command = ('update-project' if project else 'update') if update else ('add-project' if project else 'add')
    result = {}
    if update:
        if not isinstance(arguments.get('id'), str) or not arguments['id']: raise ValueError('Full item id is required')
        result['id'] = arguments['id']
    if not update and not fields.get('title'): raise ValueError('Title is required')
    for key in ('title','notes'):
        if key in fields: result[key] = fields[key] or ''
    if 'deadline' in fields or 'due' in fields: result['deadline'] = fields.get('deadline', fields.get('due')) or ''
    when = fields.get('when', fields.get('start_date'))
    if when is None and fields.get('list') in ('today','anytime','someday'): when = fields['list']
    reminder = fields.get('reminder_time', fields.get('reminder'))
    if reminder:
        # A reminder is tied to the start day in Things; do not silently assume today.
        if 'T' in reminder:
            day, clock = reminder.split('T', 1)
            if clock.endswith('Z') or '+' in clock: raise ValueError('Use local Things time YYYY-MM-DD@HH:MM, not a UTC/offset timestamp')
            when = day + '@' + clock[:5]
        elif '@' in reminder: when = reminder
        elif when: when = str(when).split('@')[0] + '@' + reminder
        else: raise ValueError('A reminder time requires start_date/when, or a full local date@time')
    if when is not None: result['when'] = when or ''
    if 'tags' in fields: result['tags'] = ','.join(fields['tags'] or [])
    if 'checklist' in fields:
        if project: raise ValueError('Projects do not have a checklist')
        if not isinstance(fields['checklist'], list) or any(not isinstance(v,str) for v in fields['checklist']): raise ValueError('checklist must be an array of strings')
        if len(fields['checklist']) > 100: raise ValueError('Things permits up to 100 checklist items')
        result['checklist-items'] = '\n'.join(fields['checklist'])
    if 'heading_id' in fields: result['heading-id'] = fields['heading_id'] or ''
    if fields.get('project_id'): result['list-id'] = fields['project_id']
    if fields.get('area_id'): result['area-id' if project else 'list-id'] = fields['area_id']
    if update and any(k in fields and fields[k] is None for k in ('project_id','area_id')): raise ValueError('Use things_ui to detach a parent; URL Scheme does not document this operation')
    if fields.get('status'):
        status = fields['status']
        if status not in ('open','completed','canceled'): raise ValueError('Unknown status')
        result['completed'] = 'true' if status == 'completed' else 'false'
        result['canceled'] = 'true' if status == 'canceled' else 'false'
    return command, result


def dispatch(tool, arguments, opener=None, timeout=12, token_path=TOKEN_PATH):
    command, fields = parameters(tool, arguments)
    if command.startswith('update'):
        try: token = Path(token_path).read_text().strip()
        except OSError: raise ValueError('Things URL authorization is not configured locally; no change dispatched')
        if not token: raise ValueError('Empty Things URL authorization; no change dispatched')
        fields['auth-token'] = token
    receipt = {}
    done = threading.Event()
    nonce = secrets.token_urlsafe(24)
    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *args): pass
        def do_GET(self):
            parsed = urlsplit(self.path)
            expected = '/'+nonce+'/'
            if not parsed.path.startswith(expected) or parsed.path[len(expected):] not in ('success','error','cancel'):
                self.send_error(404);return
            receipt.update(kind=parsed.path[len(expected):], values=parse_qs(parsed.query))
            self.send_response(200);self.send_header('Content-Type','text/plain; charset=utf-8');self.end_headers()
            self.wfile.write(b'Things command received. You may close this tab.')
            done.set()
    server = http.server.ThreadingHTTPServer(('127.0.0.1',0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True);thread.start()
    base = f'http://127.0.0.1:{server.server_port}/{nonce}/'
    fields.update({'x-success':base+'success','x-error':base+'error','x-cancel':base+'cancel'})
    url = 'things:///'+command+'?'+urlencode(fields)
    try:
        if opener is None:
            # Do not print the URL: update URLs contain the local authorization token.
            subprocess.run(['/usr/bin/open','-g',url],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        else: opener(url)
        if not done.wait(timeout):
            return {'ok':False,'error':'RESULT_UNCONFIRMED: Things did not return a callback; inspect item before retrying to avoid duplicates','may_have_changed':True}
        values = receipt.get('values',{})
        if receipt['kind'] != 'success': return {'ok':False,'error':receipt['kind'],'details':values,'may_have_changed':False}
        return {'ok':True,'acknowledged_by':'Things x-success','id':values.get('x-things-id',[arguments.get('id')])[0], 'verified_fields':False,'next':'Read the item to verify requested fields; Things can ignore missing tags/headings'}
    finally:
        server.shutdown();server.server_close()
