#!/usr/bin/env python3
"""MCP server for Things3 (mcp 2.x).

Wraps /Users/max/bin/things as MCP tools over stdio JSON-RPC.
"""
import asyncio
import datetime as _dt
import json
import os
import subprocess
import sys
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    CallToolRequest,
    CallToolResult,
    ListToolsRequest,
    ListToolsResult,
    TextContent,
    Tool,
)

THINGS = "/Users/max/bin/things"
CONTRACT_PATH = "/Users/max/.hermes/scripts/things_tools_contract.json"


def parse_json_list(out: str) -> list[dict]:
    value = json.loads(out or "[]")
    if not isinstance(value, list) or any(not isinstance(item, dict) for item in value):
        raise ValueError("Things JSON response must be an array of objects")
    return value


def run(args: list[str]) -> tuple[str, str, int]:
    r = subprocess.run([THINGS, *args], capture_output=True, text=True)
    return r.stdout, r.stderr, r.returncode


def _row_line(line: str) -> dict[str, str] | None:
    line = line.strip()
    if not line:
        return None
    if line.startswith("* "):
        line = line[2:]
    if "  [" in line:
        title, _, rest = line.partition("  [")
        flags_and_id = rest.rstrip("]")
        last_bracket = flags_and_id.rfind("[")
        if last_bracket >= 0:
            flags = flags_and_id[:last_bracket].strip().strip(",").strip()
            uid = flags_and_id[last_bracket + 1:]
        else:
            flags = ""
            uid = flags_and_id
        return {"title": title.strip(), "id": uid.strip(), "flags": flags}
    return {"title": line}


def parse_list(out: str) -> list[dict[str, str]]:
    items = []
    for line in out.splitlines():
        if not line.strip() or line.startswith("multiple matches:"):
            continue
        parsed = _row_line(line)
        if parsed:
            items.append(parsed)
    return items


def _ok(text: str) -> CallToolResult:
    return CallToolResult(content=[TextContent(type="text", text=text)])


def _err(msg: str) -> CallToolResult:
    return CallToolResult(
        content=[TextContent(type="text", text=f"ERROR: {msg.strip()}")],
        isError=True,
    )


def _struct(payload: Any) -> CallToolResult:
    return CallToolResult(
        content=[TextContent(type="text", text=json.dumps(payload, ensure_ascii=False, indent=2))]
    )


def _list_cmd(args: list[str]) -> CallToolResult:
    out, err, rc = run([*args, "--json"])
    if rc != 0:
        return _err(err or f"things {args} exited {rc}")
    try:
        return _struct(parse_json_list(out))
    except (ValueError, json.JSONDecodeError) as e:
        return _err(f"invalid structured Things response: {e}")


def _simple(args: list[str]) -> CallToolResult:
    out, err, rc = run(args)
    if rc != 0:
        return _err(err or f"things {args} exited {rc}")
    return _ok(out)


def _dispatch(name: str, arguments: dict) -> CallToolResult:
    try:
        if name in ("things_add", "things_update", "things_project_add", "things_project_update"):
            from things_url import dispatch
            result = dispatch(name, arguments)
            return _struct(result) if result.get("ok") else _err(json.dumps(result, ensure_ascii=False))
        if name == "things_ui":
            helper = os.path.expanduser("~/Applications/TaskFlow Things Access.app/Contents/MacOS/ThingsAccess")
            r = subprocess.run([helper], input=json.dumps(arguments), capture_output=True, text=True, timeout=30)
            value = json.loads(r.stdout)
            if r.returncode != 0 or not value.get("ok"):
                return _err(json.dumps(value.get("error", value), ensure_ascii=False))
            return _struct(value)
        if name == "things_today":     return _list_cmd(["today"])
        if name == "things_inbox":     return _list_cmd(["inbox"])
        if name == "things_upcoming":  return _list_cmd(["upcoming"])
        if name == "things_anytime":   return _list_cmd(["anytime"])
        if name == "things_someday":   return _list_cmd(["someday"])
        if name == "things_projects":  return _list_cmd(["projects"])
        if name == "things_areas":     return _list_cmd(["areas"])
        if name == "things_search":
            return _list_cmd(["search", arguments["query"]])
        if name == "things_list":
            key = arguments["list"]
            if key not in {"today", "inbox", "upcoming", "anytime", "someday", "logbook", "trash"}:
                return _err(f"Things list '{key}' is not currently supported by the CLI")
            return _list_cmd([key])
        if name == "things_get":
            out, err, rc = run(["get", arguments["id"], "--json"])
            if rc != 0:
                return _err(err or f"things get exited {rc}")
            value = json.loads(out)
            if not isinstance(value, dict):
                return _err("invalid structured Things response: expected one object")
            return _struct(value)

        if name == "things_add":
            if arguments.get("recurrence") is not None:
                return _err("Things repeat rules are not writable through the documented AppleScript/URL Scheme API")
            if any(arguments.get(key) is not None for key in ("reminder_time", "checklist", "heading_id")):
                return _err("This create field requires a configured Things Shortcut bridge (or URL Scheme authorization where applicable); no item was created")
            a = ["add", arguments["title"]]
            if arguments.get("notes"): a += ["-n", arguments["notes"]]
            if arguments.get("due"):   a += ["-d", arguments["due"]]
            if arguments.get("when"):  a += ["--when", arguments["when"]]
            for tag in arguments.get("tags") or []: a += ["--tag", tag]
            if arguments.get("project_id"): a += ["--project-id", arguments["project_id"]]
            if arguments.get("area_id"): a += ["--area-id", arguments["area_id"]]
            lst = arguments.get("list") or "inbox"
            if lst and lst not in ("inbox",):
                a += ["-l", lst]
            a.append("--json")
            return _simple(a)

        if name == "things_project_add":
            a = ["project-add", arguments["title"]]
            if arguments.get("notes") is not None: a += ["--notes", arguments["notes"]]
            if arguments.get("deadline") is not None: a += ["--deadline", arguments["deadline"]]
            if arguments.get("area_id"): a += ["--area-id", arguments["area_id"]]
            for tag in arguments.get("tags") or []: a += ["--tag", tag]
            a += ["--json"]
            return _simple(a)

        if name == "things_project_update":
            patch = arguments.get("patch") or {}
            names = {"title": "--title", "notes": "--notes", "deadline": "--deadline",
                     "tags": "--tag", "area_id": "--area-id", "status": "--status", "start_date": "--start-date"}
            unknown = set(patch) - set(names)
            if unknown: return _err(f"Unsupported project field(s): {', '.join(sorted(unknown))}; no change made")
            a = ["project-update", arguments["id"]]
            for field, flag in names.items():
                if field not in patch: continue
                val = patch[field]
                if field == "tags":
                    if not val: a.append("--clear-tags")
                    else:
                        for tag in val: a += [flag, str(tag)]
                elif field == "area_id" and val is None:
                    # The AppleScript dictionary documents area movement but no reliable detach helper here.
                    return _err("Clearing a project's area is not supported by this operation; no change made")
                else: a += [flag, "" if val is None else str(val)]
            a += ["--json"]
            return _simple(a)

        if name == "things_update":
            patch = arguments.get("patch") or {}
            if "recurrence" in patch:
                return _err("Repeat rules are not writable through the documented Things APIs; no change made")
            if any(key in patch for key in ("reminder", "checklist", "heading_id")):
                return _err("No Shortcut bridge is configured for this field. Things URL Scheme updates require auth-token from Things → Settings → General → Enable Things URLs → Manage; this integration does not yet dispatch that URL, so no change was made")
            names = {"title": "--title", "notes": "--notes", "deadline": "--deadline",
                     "start_date": "--start-date", "project_id": "--project-id", "area_id": "--area-id",
                     "status": "--status", "tags": "--tag"}
            unknown = set(patch) - set(names)
            if unknown:
                return _err(f"Unsupported update field(s): {', '.join(sorted(unknown))}; no change made")
            a = ["update", arguments["id"]]
            for field, flag in names.items():
                if field not in patch: continue
                val = patch[field]
                if field == "tags":
                    if not val: a.append("--clear-tags")
                    else:
                        for tag in val: a += [flag, str(tag)]
                elif field in ("project_id", "area_id") and val is None:
                    a.append("--clear-project" if field == "project_id" else "--clear-area")
                else:
                    a += [flag, "" if val is None else str(val)]
            a.append("--json")
            return _simple(a)
        if name == "things_cancel": return _simple(["cancel", arguments["id"], "--json"])
        if name == "things_reopen": return _simple(["reopen", arguments["id"], "--json"])
        if name == "things_delete": return _simple(["delete", arguments["id"], "--json"])

        if name == "things_complete":
            a = ["complete", arguments["id_or_title"]]
            if arguments.get("yes"):
                a.append("-y")
            return _simple(a)

        if name == "things_show":
            return _simple(["show", arguments["id_or_title"]])

        return _err(f"unknown tool: {name}")
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


with open(CONTRACT_PATH, encoding="utf-8") as _contract_file:
    CONTRACT = json.load(_contract_file)
TOOLS = [Tool(name=t["name"], description=t["description"], inputSchema=t["inputSchema"])
         for t in CONTRACT["tools"]]


server = Server("things3")


async def _handle_list(ctx, req: ListToolsRequest) -> ListToolsResult:
    return ListToolsResult(tools=TOOLS)


async def _handle_call(ctx, req: CallToolRequest) -> CallToolResult:
    name = req.params.name
    arguments = req.params.arguments or {}
    return _dispatch(name, arguments)


server.add_request_handler("tools/list", ListToolsRequest, _handle_list)
server.add_request_handler("tools/call", CallToolRequest, _handle_call)


# === BOOTSTRAP STUB: minimal raw stdio JSON-RPC dispatcher ===
# Replaces `server.run()` to bypass the mcp 2.x ServerRunner, whose pydantic
# surface validation rejects our tools/call envelope with -32602.
# Implements: initialize, notifications/initialized, tools/list, tools/call.
def _make_initialize_result():
    return {
        "protocolVersion": "2025-11-25",
        "capabilities": {"tools": {"listChanged": False}},
        "serverInfo": {"name": "things3", "version": "1.0.0"},
    }


def _tool_to_dict(t):
    return {
        "name": t.name,
        "description": t.description,
        "inputSchema": t.input_schema,
    }


async def _call_dispatch(name: str, arguments: dict) -> dict:
    """Return {"content": [...], "isError": bool} for the tool."""
    import asyncio

    class _FakeReq:
        class _Params:
            def __init__(self, n, a):
                self.name = n
                self.arguments = a or {}
        def __init__(self, n, a):
            self.params = self._Params(n, a)
    fake = _FakeReq(name, arguments)
    res = await _handle_call(None, fake)
    return {
        "content": [{"type": c.type, "text": c.text} for c in res.content],
        "isError": getattr(res, "isError", False),
    }


async def main():
    """Minimal raw-stdio JSON-RPC dispatcher. Speaks MCP protocol well enough for our client."""
    loop = asyncio.get_event_loop()
    reader = asyncio.StreamReader()
    protocol = asyncio.StreamReaderProtocol(reader)
    await loop.connect_read_pipe(lambda: protocol, sys.stdin)

    write_transport, _ = await loop.connect_write_pipe(asyncio.streams.FlowControlMixin, sys.stdout)
    writer = asyncio.StreamWriter(write_transport, protocol, reader, loop)

    async def _send(payload: dict):
        line = json.dumps(payload) + "\n"
        writer.write(line.encode())
        await writer.drain()

    while True:
        try:
            raw = await reader.readline()
        except Exception:
            break
        if not raw:
            break
        try:
            msg = json.loads(raw.decode())
        except Exception:
            continue

        method = msg.get("method")
        req_id = msg.get("id")
        params = msg.get("params") or {}

        if method == "initialize":
            await _send({"jsonrpc": "2.0", "id": req_id, "result": _make_initialize_result()})
            continue

        if method == "notifications/initialized" or method == "notifications/cancelled":
            continue  # fire-and-forget

        if method == "ping":
            await _send({"jsonrpc": "2.0", "id": req_id, "result": {}})
            continue

        if method == "tools/list":
            tools_list = [_tool_to_dict(t) for t in TOOLS]
            await _send({"jsonrpc": "2.0", "id": req_id, "result": {"tools": tools_list}})
            continue

        if method == "tools/call":
            tool_name = params.get("name")
            arguments = params.get("arguments") or {}
            if not tool_name:
                await _send({"jsonrpc": "2.0", "id": req_id, "error": {"code": -32602, "message": "missing tool name"}})
                continue
            try:
                result = await _call_dispatch(tool_name, arguments)
                await _send({"jsonrpc": "2.0", "id": req_id, "result": result})
            except Exception as e:
                await _send({
                    "jsonrpc": "2.0", "id": req_id,
                    "error": {"code": -32603, "message": f"{type(e).__name__}: {e}"},
                })
            continue

        # Unknown method
        if req_id is not None:
            await _send({
                "jsonrpc": "2.0", "id": req_id,
                "error": {"code": -32601, "message": f"Method not found: {method}"},
            })


if __name__ == "__main__":
    asyncio.run(main())
