import importlib.util
import importlib.machinery
import json
import pathlib
import sqlite3
import tempfile
import unittest
import sys
from contextlib import contextmanager
from unittest.mock import patch
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))


SCRIPT = pathlib.Path(__file__).resolve().parents[1] / "things_mcp_server.py"
SPEC = importlib.util.spec_from_file_location("things_mcp_server", SCRIPT)
things = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(things)
CLI_LOADER = importlib.machinery.SourceFileLoader("things_cli", "/Users/max/bin/things")
CLI_SPEC = importlib.util.spec_from_loader("things_cli", CLI_LOADER)
cli = importlib.util.module_from_spec(CLI_SPEC)
CLI_SPEC.loader.exec_module(cli)


class ThingsStructuredAPITests(unittest.TestCase):
    def test_read_only_snapshot_includes_committed_wal_pages_without_mutating_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = pathlib.Path(tmp) / "things.sqlite"
            writer = sqlite3.connect(source)
            writer.execute("PRAGMA journal_mode=WAL")
            writer.execute("PRAGMA wal_autocheckpoint=0")
            writer.execute("CREATE TABLE TMTask (uuid TEXT, title TEXT)")
            writer.execute("INSERT INTO TMTask VALUES ('a', 'before')")
            writer.commit()
            writer.execute("UPDATE TMTask SET title='after' WHERE uuid='a'")
            writer.commit()
            wal_before = pathlib.Path(str(source) + "-wal").stat().st_size
            with cli.database_snapshot(source) as snapshot:
                self.assertNotEqual(snapshot, source)
                reader = sqlite3.connect(f"file:{snapshot}?mode=ro", uri=True)
                self.assertEqual(reader.execute("SELECT title FROM TMTask WHERE uuid='a'").fetchone()[0], "after")
                reader.close()
                self.assertTrue(snapshot.exists())
            self.assertFalse(snapshot.exists())
            self.assertEqual(pathlib.Path(str(source) + "-wal").stat().st_size, wal_before)
            writer.close()

    def test_fixture_schema_retains_full_id_notes_dates_and_marks_unavailable_fields(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = pathlib.Path(tmp) / "fixture.sqlite"
            con = sqlite3.connect(db)
            con.execute("CREATE TABLE TMTask (uuid TEXT, type INTEGER, title TEXT, notes TEXT, start INTEGER, startDate TEXT, deadline TEXT, reminderTime TEXT, status INTEGER, creationDate TEXT, modificationDate TEXT, completionDate TEXT, cancellationDate TEXT, tagNames TEXT, checklistItems TEXT, projectUUID TEXT, headingUUID TEXT, recurrence TEXT)")
            con.execute("INSERT INTO TMTask VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                "0123456789abcdef0123456789abcdef", 0, "Fixture task", "real notes",
                1, "2026-10-20", "2026-10-22", "2026-10-20T09:30:00+03:00", 0,
                "2026-10-18T10:00:00Z", "2026-10-18T11:00:00Z", None, None,
                '["Work","Planning"]', '[{"title":"Draft","completed":true}]',
                "project-id", "heading-id", '{"frequency":"weekly"}'))
            con.commit()
            con.close()
            old_refresh = cli.database_snapshot
            @contextmanager
            def fixture_snapshot():
                yield db
            try:
                cli.database_snapshot = fixture_snapshot
                item = cli.fetch_one("0123456789abcdef0123456789abcdef")
            finally:
                cli.database_snapshot = old_refresh
        self.assertEqual(item["id"], "0123456789abcdef0123456789abcdef")
        self.assertEqual(item["notes"], "real notes")
        self.assertEqual(item["start_date"], "2026-10-20")
        self.assertEqual(item["deadline"], "2026-10-22")
        self.assertEqual(item["project_id"], "project-id")
        self.assertEqual(item["reminder"], "2026-10-20T09:30:00+03:00")
        self.assertEqual(item["tags"], ["Work", "Planning"])
        self.assertEqual(item["checklist"][0]["title"], "Draft")
        self.assertEqual(item["heading_id"], "heading-id")
        self.assertTrue(item["recurrence"]["available"])

    def test_parse_json_keeps_full_uuid_and_all_fields(self):
        task = {
            "id": "0123456789abcdef0123456789abcdef",
            "type": "todo",
            "title": "Prepare launch",
            "notes": "Actual notes, not a boolean flag",
            "start_date": "2026-10-20",
            "deadline": "2026-10-22",
            "reminder": "2026-10-20T09:30:00+03:00",
            "tags": ["Work", "Planning"],
            "checklist": [{"title": "Draft", "completed": True}],
            "project": {"id": "project-full-id", "title": "Launch"},
            "area": {"id": "area-full-id", "title": "Work"},
            "heading": {"id": "heading-full-id", "title": "Week 1"},
            "status": "open",
            "created": "2026-10-18T10:00:00Z",
            "modified": "2026-10-18T11:00:00Z",
            "completed": None,
            "canceled": None,
            "recurrence": None,
        }
        parsed = things.parse_json_list(json.dumps([task]))
        self.assertEqual(parsed, [task])

    def test_read_one_item_command_returns_structured_full_record(self):
        task = {"id": "0123456789abcdef0123456789abcdef", "title": "One"}
        old_run = things.run
        try:
            things.run = lambda args: (json.dumps(task), "", 0)
            result = things._dispatch("things_get", {"id": task["id"]})
        finally:
            things.run = old_run
        self.assertEqual(json.loads(result.content[0].text), task)

    def test_contract_is_the_tool_list_source_and_keeps_full_project_operations(self):
        names = [tool.name for tool in things.TOOLS]
        self.assertIn("things_project_add", names)
        self.assertIn("things_project_update", names)
        self.assertIn("things_get", names)

    def test_create_dispatch_forwards_fields_to_shared_url_handler(self):
        import things_url
        request={"title":"Fixture", "checklist":["one"]}
        with patch.object(things_url, "dispatch", return_value={"ok":True,"id":"fixture"}) as dispatch:
            result=things._dispatch("things_add",request)
            dispatch.assert_called_once_with("things_add",request)
            self.assertFalse(result.is_error)

    def test_missing_url_authorization_is_propagated(self):
        import things_url
        with patch.object(things_url, "dispatch", side_effect=ValueError("auth-token missing")):
            result=things._dispatch("things_update", {"id":"x","patch":{"checklist":[]}})
            self.assertTrue(result.is_error)
            self.assertIn("auth-token",result.content[0].text)

    def test_recurrence_is_explicitly_unsupported_for_writes(self):
        result = things._dispatch("things_update", {"id": "full-id", "patch": {"recurrence": "weekly"}})
        self.assertTrue(result.is_error)
        self.assertIn("repeat", result.content[0].text.lower())


if __name__ == "__main__":
    unittest.main()

class NativeThingsEncodingTests(unittest.TestCase):
    def test_actual_things_dates_unix_timestamps_and_status(self):
        item=cli.task_record({'uuid':'x','status':3,'startDate':(2026<<16)|(10<<12)|(20<<7), 'deadline':(2026<<16)|(10<<12)|(22<<7),'reminderTime':(14<<26)|(30<<20),'creationDate':1788784493.0,'userModificationDate':1788784493.0,'stopDate':1788784493.0,'rt1_recurrenceRule':'{"frequency":"weekly"}'})
        self.assertEqual(item['start_date'],'2026-10-20')
        self.assertEqual(item['deadline'],'2026-10-22')
        self.assertEqual(item['reminder'],'2026-10-20T14:30:00')
        self.assertEqual(item['status'],'completed')
        self.assertEqual(item['created'],'2026-09-07T12:34:53Z')
        self.assertTrue(item['recurrence']['available'])

class NativeRelationsTests(unittest.TestCase):
    def test_tags_checklist_and_parent_are_read_from_relations(self):
        c=sqlite3.connect(':memory:');c.row_factory=sqlite3.Row
        c.executescript('CREATE TABLE TMTask(uuid TEXT,title TEXT); CREATE TABLE TMTag(uuid TEXT,title TEXT,[index] INTEGER); CREATE TABLE TMTaskTag(tasks TEXT,tags TEXT); CREATE TABLE TMChecklistItem(uuid TEXT,title TEXT,status INTEGER,[index] INTEGER,task TEXT); INSERT INTO TMTask VALUES("p","Project"); INSERT INTO TMTag VALUES("t","Work",0); INSERT INTO TMTaskTag VALUES("x","t"); INSERT INTO TMChecklistItem VALUES("c","Step",3,0,"x");')
        row=cli.hydrate_row(c,{'uuid':'x','status':0,'project':'p'})
        item=cli.task_record(row)
        self.assertEqual(item['tags'],['Work'])
        self.assertTrue(item['checklist'][0]['completed'])
        self.assertEqual(item['project']['title'],'Project')
        c.close()

    def test_list_filters_follow_native_start_codes_and_hide_trash(self):
        for name, code in [('inbox',0),('anytime',1),('someday',2)]:
            query=cli.task_query(name)
            self.assertIn(f'start={code}',query)
            self.assertIn('trashed=0',query)
        self.assertIn('status IN (2,3)',cli.task_query('logbook'))
        self.assertIn('trashed=1',cli.task_query('trash'))
