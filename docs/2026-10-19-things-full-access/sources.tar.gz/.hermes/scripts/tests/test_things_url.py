import importlib.util
import pathlib
import unittest
import urllib.parse
import urllib.request

P = pathlib.Path(__file__).resolve().parents[1] / 'things_url.py'
S = importlib.util.spec_from_file_location('things_url', P)
u = importlib.util.module_from_spec(S)
S.loader.exec_module(u)

class URLTests(unittest.TestCase):
    def test_create_preserves_reminder_checklist_tags_and_heading(self):
        command, fields = u.parameters('things_add', {'title':'A & B','when':'2026-10-20','reminder_time':'14:30','checklist':['one','two'],'tags':['tag'],'project_id':'p','heading_id':'h'})
        self.assertEqual(command,'add')
        self.assertEqual(fields['when'],'2026-10-20@14:30')
        self.assertEqual(fields['checklist-items'],'one\ntwo')
        self.assertEqual(fields['heading-id'],'h')

    def test_unknown_and_repeat_fields_do_not_write(self):
        for patch in [{'unknown':1},{'recurrence':None}]:
            with self.assertRaises(ValueError): u.parameters('things_update', {'id':'x','patch':patch})

    def test_success_requires_callback_receipt(self):
        def opener(url):
            q=urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
            urllib.request.urlopen(q['x-success'][0]+'?x-things-id=fixture-id').read()
        result=u.dispatch('things_add', {'title':'fixture'}, opener=opener, timeout=1)
        self.assertTrue(result['ok']);self.assertEqual(result['id'],'fixture-id')

    def test_open_without_receipt_is_never_success(self):
        result=u.dispatch('things_add', {'title':'fixture'}, opener=lambda url:None, timeout=.02)
        self.assertFalse(result['ok']);self.assertTrue(result['may_have_changed'])

    def test_update_needs_local_token(self):
        with self.assertRaises(ValueError):u.dispatch('things_update',{'id':'x','patch':{'notes':'new'}},token_path='/nonexistent',opener=lambda url:None)

if __name__=='__main__':unittest.main()
